import Enviroment.base as base

class EnviromentSimilarStatic(base.Enviroment):
    pass
