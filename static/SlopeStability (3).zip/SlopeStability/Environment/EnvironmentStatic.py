import Enviroment.base as base

class EnviromentStatic(base.Enviroment):
    pass