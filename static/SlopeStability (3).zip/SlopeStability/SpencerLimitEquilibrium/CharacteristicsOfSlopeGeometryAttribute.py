class CharacteristicsOfSlopeGeometryAttribute:
    def __init__(self,height,waterHeightLeft,waterHeightRight):
        self.height = height
        self.waterHeightLeft = waterHeightLeft
        self.waterHeightRight = waterHeightRight
